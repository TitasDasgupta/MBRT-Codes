close all
clear all

%% ------------------------------------------------------------------------------------------------------------------------------
%% MBRT Code (EBS Model: 1 Conduction Band & 1 Valence Band, Scattering Mechanism: Acoustic Phonon and Grain Boundary Scattering of charge carriers)
%% Example File: Si (experimental data file:Experimental_Data_Mg2Si_Undoped.xlsx, Guess Values File:Parameter_File.xlsx )   


%% Universal Constants 
kb=1.3807e-23; e=1.60219e-19; m=9.1095e-31; h=6.6262e-34;hbar=1.054571e-34;
k=8.617e-5;

%% ------------------------------------------------------------------------------------
%% Input File Information
data=xlsread('Experimental_Data_Mg2Si_Undoped.xlsx'); % Input file for S,sigma,RH
store=xlsread('Parameter_File.xlsx'); %File to store the variables after each cycle    

no=37; % User defined number of temperature points 


%% ------------------
%% Material Constants
%% ------------------

vL=7680    ; % Velocity of sound in Mg2Si       
d=1920     ; % density of Mg2Si 

%% -------------------
%% Degeneracy of Bands
%% -------------------

Nvn1 = 3  ;  % Degeneracy of conduction band at X point
Nvp  = 2 ;  % Degeneracy of valence band at gamma point



%% ------------------------------
%% Function Declaration 
%% ------------------------------

%% Fermi Integral
%Fermi Integrand
FI=@(ene,eta,j)(ene.^j)./(1+exp(ene-eta));
%Fermi Integral
F=@(eta,j)quadgk(@(ene)FI(ene,eta,j),0,inf);
%% ------------------------------

%% ------------------------------
%% Band Gap
Eg=@(T,a,Eg0)(Eg0-a*T)/(k*T);

%% Single Valley Mass
mn1s=@(mdn1)mdn1/(Nvn1^(2/3));
mps=@(mdp)(mdp)/(Nvp^(2/3));
%% ------------------------------


%% ---------------------------
%% Charge Transport Properties
%% ---------------------------


%% Charge Carrier Concentration (individual Band)
n_1=@(eta,T,mdn1) 4*pi*((2*mdn1*kb*T/(h*h))^(1.5))*F(eta,0.5);
n_p=@(eta,T,a,mdp,Eg0) 4*pi*((2*mdp*kb*T/(h*h))^(1.5))*F(-eta-Eg(T,a,Eg0),0.5);

%% Free Mobility Function_Acoustic Phonon Scattering (individual band)
mu0n1_ap=@(T,Edefn1,mdn1)(e*pi*(hbar^4)*(vL^2)*d)/((sqrt(2))*(Edefn1^2)*((mn1s(mdn1)*kb*T)^1.5)*mn1s(mdn1));
mu0p_ap=@(T,Edefp,mdp)(e*pi*(hbar^4)*(vL^2)*d)/((sqrt(2))*(Edefp^2)*((mps(mdp)*kb*T)^1.5)*mps(mdp));

%% Free Mobility Function_Grain Boundary Scattering (individual band)
mu0n1_gb=@(T,Eb,mdn1,L)(L*e*(2*pi*mn1s(mdn1)*kb*T)^(-0.5)*exp(-Eb/(k*T)));
mu0p_gb=@(T,Eb,mdp,L,a,Eg0)(L*e*(2*pi*mps(mdp)*kb*T)^(-0.5)*exp((Eb/(k*T))+Eg(T,a,Eg0)));

%% Free Mobility Function_TOTAL (individual Band)
mu0n1 = @(T,Edefn1,mdn1,Eb,L)((mu0n1_ap(T,Edefn1,mdn1))^(-1) +(mu0n1_gb(T,Eb,mdn1,L))^(-1) )^(-1);
mu0p = @(T,Edefp,mdp,Eb,L,a,Eg0)((mu0p_ap(T,Edefp,mdp))^(-1) + (mu0p_gb(T,Eb,mdp,L,a,Eg0))^(-1))^(-1);

%% Electrical Conductivity (individual band) 
sig_n1=@(eta,T,Edefn1,mdn1,Eb,L)(8*pi*e/(3*h^3))*mu0n1(T,Edefn1,mdn1,Eb,L)*Nvn1*((2*mn1s(mdn1)*kb*T)^1.5)*F(eta,0);
sig_p=@(eta,T,Edefp,mdp,a,Eg0,Eb,L)(8*pi*e/(3*h^3))*mu0p(T,Edefp,mdp,Eb,L,a,Eg0)*Nvp*((2*mps(mdp)*kb*T)^1.5)*F(-eta-Eg(T,a,Eg0),0);

%% Seebeck Coefficient (individual band)
Sbk_n1=@(eta)-(kb/e)*((2*F(eta,1)/F(eta,0))-eta);
Sbk_p=@(eta,T,a,Eg0)-(kb/e)*((2*F(-eta-Eg(T,a,Eg0),1)/F(-eta-Eg(T,a,Eg0),0))-(-eta-Eg(T,a,Eg0)));

%% Hall Prefactor (rH) (individual band)
rH_n1= @(eta) 1.5*F(eta,0.5)*F(eta,-0.5)/(2*F(eta,0)*F(eta,0));
rH_p= @(eta,T,a,Eg0) 1.5*F(-eta-Eg(T,a,Eg0),0.5)*F(-eta-Eg(T,a,Eg0),-0.5)/(2*F(-eta-Eg(T,a,Eg0),0)*F(-eta-Eg(T,a,Eg0),0));
%% -----------------------------------------------------------------------------------------------------------------------


for cy=2:1:50   %(User defined number of refinement cycles )
  
   Nd1= store(1,cy-1);       % Donor Concentration 
   mdn1= store(2,cy-1)*m;    % DOS mass of conduction band                              
   Edefn1= store(3,cy-1)*e;  % Deformation potential of conduction band 
   Eg0=store(4,cy-1);        % Band gap at zero Kelvin                           
   a=store(5,cy-1);          % Band gap temperature constant              
   mdp= store(6,cy-1)*m;     % DOS mass of valence band
   Edefp= store(7,cy-1)*e;   % Deformation potential of valence band
   Eb= store(8,cy-1);        % Grain Boundary Barrier Activation Potential
   L=store(9,cy-1);          % Grain Size
    
%% Printing Refinement Parameters 
    
     fprintf('value of Nd1: %d\n', Nd1); 

     fprintf('value of  Eg0: %d\n', Eg0); 
     fprintf('value of  a: %d\n', a); 
     
     fprintf('value of  mdn1: %d\n', mdn1/m); 
     fprintf('value of  Edefn1: %d\n', Edefn1/e); 
     
     fprintf('value of  mdp: %d\n', mdp/m); 
     fprintf('value of  Edefp: %d\n', Edefp/e); 
     
     fprintf('value 0f Nvn1 %d\n', Nvn1);
     fprintf('value 0f Nvp %d\n', Nvp);
     
     fprintf('value 0f vL %d\n', vL);
     fprintf('value 0f d %d\n', d);
          
 
%%  Index for Error array calculation for each refinement loop [Coarse and fine grids]
r1=1;
r11=1;
r2=1;
r22=1;
r3=1;
r33=1;
r4=1;
r44=1;
r5=1;
r55=1;
r6=1;
r66=1;
r7=1;
r77=1;
r8=1;
r88=1;
r9=1;
r99=1;


%% *************0**************0*************0************0************0*****************0
%% 1.Donor concentration optimization
%% *************0**************0*************0************0************0*****************0
X=(Nd1/20);     %[Step size for coarse grid]
Ns=(Nd1-5*X);   %[Starting value for coarse grid] 
Ne=(Nd1+5*X);   %[End value for coarse grid]

for fa=2:2:100       %[Maximum number of trials to reach minima]
for Nd= Ns :X: Ne;   %{Loop1 Coarse Grid}
y11=0;               % counter

for i=1:37;
T=data(i,1);    
%% Charge Balance Equation (Nd=n-p)
ND=@(eta)n_1(eta,T,mdn1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,0);

%% Calculate Electrical Conductivity for Two Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Two Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values 
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Two Band System
n1(i)=n_1(et(i),T,mdn1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+-Rhp(i)*((sigp(i))^2))/((sig(i))^2);

%% Error Calculation
Er11(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;
y11=y11+Er11(i);

end
  Error11(r11)=y11/no;
   X11(r11)=Nd;
  r11=r11+1;
  
figure(cy*1000+1*100)
  hold on
      plot(Nd,y11/no,'o')
      hold off
end 
  [Min11, i11dx]= min(Error11);
    Nd11= X11(i11dx);
   fprintf('value of Nd11: %d\n', Nd11);
    fprintf('value of Ne: %d\n', Ne);
    fprintf('value of Ns: %d\n', Ns);
   
        if (round (Nd11,5) > round(Ns,5) && round (Nd11,5) < round(Ne,5))== true
             break;  
        else
            Ne=Nd11+4*X;
            Ns=Nd11-4*X;
           
        end
end   
%% -------------------------------*()------------------------------------*()---------------------------- 
%% for  Nd= Nd11-X:X/10:Nd11+X;  
 for Nd= Nd11-X:X/10:Nd11+X; %% {Loop 2 Fine Grid}
  y1=0;   
   for i=1:37;
T=data(i,1);  

%%  Charge Balance Equation (Nd=n-p)
ND=@(eta)n_1(eta,T,mdn1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Two Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Two Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values  
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Two Band System
n1(i)=n_1(et(i),T,mdn1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+-Rhp(i)*((sigp(i))^2))/((sig(i))^2);



%% Error Calculation
 Er1(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;
 y1=y1+Er1(i);


end
  Error1(r1)=y1/no;
   X1(r1)=Nd;
  r1=r1+1;
  
figure(cy*100+1)
  hold on
      plot(Nd,y1/no,'o')
      hold off
end
  [Min1 ,i1dx]= min(Error1);
    Nd1= X1(i1dx);


%% *************0**************0*************0************0************0*****************0
%% 2. D.O.S. mass of C.B._mdn1_ optimization 
%% *************0**************0*************0************0************0*****************0
Xm1=(mdn1/100)/2;    %[Step size for coarse grid] 
mdn1s=(mdn1-5*Xm1);  %[Starting value for coarse grid]  
mdn1e= (mdn1+5*Xm1); %[End value for coarse grid]

for fa2=1:1:100000 
for mdn1=mdn1s:Xm1:mdn1e     %% {Loop1 Coarse Grid}
Nd=Nd1;
y22=0;

for i=1:37;
T=data(i,1);  

%% Charge Balance Equation (Nd=n-p)
ND=@(eta)n_1(eta,T,mdn1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Two Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Two Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values  
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Two Band System
n1(i)=n_1(et(i),T,mdn1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+-Rhp(i)*((sigp(i))^2))/((sig(i))^2);
 
 %% Error Calculation
 Er22(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;
 y22=y22+Er22(i);

end

 Error22(r22)=y22/no;
   X22(r22)=mdn1/m;
  r22=r22+1;
figure(cy*1000+2*100)
  hold on
      plot(mdn1/m,y22/no,'o')
      hold off
end
   
  [Min22 i22dx]= min(Error22);
    mdn1_11= X22(i22dx)*m;
     fprintf('value of mdn1_11: %d\n', mdn1_11);
    fprintf('value of mdn1e: %d\n', mdn1e);
    fprintf('value of mdn1s: %d\n', mdn1s);
    
          if (round(mdn1_11/m,8) > round(mdn1s/m,8) && round(mdn1_11/m,8) < round(mdn1e/m,8))== true;

            break;
        else
            mdn1e=mdn1_11+4*Xm1;
            mdn1s=mdn1_11-4*Xm1;    
         end
end   

%% -----------------------------*()----------------------------------*()----------------------------    
 
for mdn1=mdn1_11-Xm1:Xm1/20:mdn1_11+Xm1;   %%  { Loop 2 Fine Grid }
Nd=Nd1;
y2=0;

for i=1:37;
T=data(i,1); 

%% Charge Balance Equation (Nd=n-p)
ND=@(eta)n_1(eta,T,mdn1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Two Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Two Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values  
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Two Band System
n1(i)=n_1(et(i),T,mdn1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+-Rhp(i)*((sigp(i))^2))/((sig(i))^2);

 
%% Error Calculation
 Er2(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;
 y2=y2+Er2(i);

end

 Error2(r2)=y2/no;
 X2(r2)=mdn1/m;
 r2=r2+1;
figure(cy*100+2)
  hold on
  plot(mdn1/m,y2/no,'o')
  hold off
end
[Min2 i2dx]= min(Error2);
    mdn1_1= X2(i2dx);
    
%% *************0**************0*************0************0************0*****************0
%% 3.Deformation Potential _Edefn1_ of C.B. optimization 
%% *************0**************0*************0************0************0*****************0
Xe1=(Edefn1/110)/2;      %[Step size for coarse grid]
Edefn1s=(Edefn1-5*Xe1);  %[Starting value for coarse grid] 
Edefn1e=(Edefn1+5*Xe1);  %[End value for coarse grid]
for fa3=1:1:100000
 for Edefn1 =  Edefn1s : Xe1 : Edefn1e;        %% {Loop1 Coarse Grid}
Nd=Nd1;
mdn1=mdn1_1*m; 

y33=0;

for i=1:37;
T=data(i,1);    
%% Charge Balance Equation (Nd=n-p)

ND=@(eta)n_1(eta,T,mdn1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Two Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Two Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values  
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Two Band System
n1(i)=n_1(et(i),T,mdn1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+-Rhp(i)*((sigp(i))^2))/((sig(i))^2);

 %% Error Calculation
 Er33(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;                            
 y33=y33+Er33(i);

end
 Error33(r33)=y33/no;
   X33(r33)=Edefn1/e;
  r33=r33+1;
figure(cy*1000+3*100)
  hold on
      plot(Edefn1/e,y33/no,'o')
      hold off
end
    [Min33 i33dx]= min(Error33);
    Edefn1_11= X33(i33dx)*e;

    fprintf('value of Edefn1_11: %d\n', Edefn1_11);
    fprintf('value of Edefn1e: %d\n', Edefn1e);
    fprintf('value of Edefn1s: %d\n', Edefn1s);
    
            if (round(Edefn1_11/e,8) > round(Edefn1s/e,8) && round(Edefn1_11/e,8) < round(Edefn1e/e,8))== true
                break;
            else
                Edefn1e=Edefn1_11+4*Xe1;
                Edefn1s=Edefn1_11-4*Xe1;
            
            end

end     
 
%% ----------------------------*()---------------------------------*()------------------------------------------

for Edefn1=(Edefn1_11-Xe1): Xe1/20 : (Edefn1_11+Xe1);   %% { Loop 2 Fine Grid }
Nd=Nd1;
mdn1=mdn1_1*m; 
y3=0;

for i=1:37;
T=data(i,1);    

%% Charge Balance Equation (Nd=n-p)
ND=@(eta)n_1(eta,T,mdn1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Two Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Two Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values  
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Two Band System
n1(i)=n_1(et(i),T,mdn1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+-Rhp(i)*((sigp(i))^2))/((sig(i))^2);

%% Error Calculation
Er3(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;                            
y3=y3+Er3(i);

end
 Error3(r3)=y3/no;
 X3(r3)=Edefn1/e;
 r3=r3+1;
figure(cy*100+3)
  hold on
  plot(Edefn1/e,y3/no,'o')
  hold off
end
 [Min3 i3dx]= min(Error3);
 Edefn1_1= X3(i3dx);   
     
    
%% *************0**************0*************0************0************0*****************0
%% 4.Band Gap Zero Kelvin Value _Eg0_ optimization 
%% *************0**************0*************0************0************0*****************0
 Xg=(Eg0/24)/2;    %[Step size for coarse grid]
 Eg0s=(Eg0-5*Xg);  %[Starting value for coarse grid] 
 Eg0e= (Eg0+5*Xg); %[End value for coarse grid]

for fa4=1:1:100000      
for Eg0=  Eg0s : Xg : Eg0e;   %% {Loop1 Coarse Grid}
Nd=Nd1;
mdn1= mdn1_1*m;  
Edefn1=Edefn1_1*e;
y44=0;
for i=1:37;
T=data(i,1); 

%% Charge Balance Equation (Nd=n-p)
ND=@(eta)n_1(eta,T,mdn1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Two Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Two Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values  
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Two Band System
n1(i)=n_1(et(i),T,mdn1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+-Rhp(i)*((sigp(i))^2))/((sig(i))^2);


%% Error Calculation
 Er44(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;
 y44=y44+Er44(i);

end

 Error44(r44)=y44/no;
   X44(r44)=Eg0;
  r44=r44+1;
  figure(cy*1000+4*100)
  hold on
      plot(Eg0,y44/no,'o')
  hold off
end  

[Min44 i44dx]= min(Error44);
   Eg0_11= X44(i44dx); 
   
      fprintf('value of Eg0_11: %d\n',Eg0_11);
    fprintf('value of Eg0e: %d\n', Eg0e);
    fprintf('value of Eg0s: %d\n',Eg0s);

        if (round(Eg0_11,8) < round(Eg0e,8) && round(Eg0_11,8) > round(Eg0s,8))== true
            break;  
        else
            Eg0e=Eg0_11+4*Xg;
            Eg0s=Eg0_11-4*Xg;
        end   
   

end  

%% -----------------------------*()------------------------------------*()----------------------------     

for Eg0=Eg0_11-Xg : 2*Xg/10 : Eg0_11+Xg;  % (Loop 2 Fine Grid ) 
Nd=Nd1;
mdn1= mdn1_1*m;  
Edefn1=Edefn1_1*e;
y4=0;
    
for i=1:37;
T=data(i,1);    

%% Charge Balance Equation (Nd=n-p)
ND=@(eta)n_1(eta,T,mdn1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Two Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Two Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values  
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Two Band System
n1(i)=n_1(et(i),T,mdn1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+-Rhp(i)*((sigp(i))^2))/((sig(i))^2);

%% Error Calculation
 Er4(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;
 y4=y4+Er4(i);

end

 Error4(r4)=y4/no;
   X4(r4)=Eg0;
  r4=r4+1;
  figure(cy*100+4)
  hold on
  plot(Eg0,y4/no,'o')
  hold off
end

[Min4,i4dx]= min(Error4);
   Eg0_1= X4(i4dx)   ; 

   
%% *************0**************0*************0************0************0*****************0
%% 5.Band Gap Temperature  Cofficient_a_ optimization 
%% *************0**************0*************0************0************0*****************0
 Xa=(a/20)/2;  %[Step size for coarse grid]
as=(a-5*Xa);   %[Starting value for coarse grid] 
ae=(a+5*Xa);   %[End value for coarse grid]

for fa5=1:1:100000 
for a = as:Xa:ae;  %% {Loop1 Coarse Grid}
Nd=Nd1; 
mdn1= mdn1_1*m;  
Edefn1=Edefn1_1*e;
Eg0=Eg0_1;
y55=0;  
for i=1:37;
T=data(i,1); 

%% Charge Balance Equation (Nd=n-p)
ND=@(eta)n_1(eta,T,mdn1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Two Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Two Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values  
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Two Band System
n1(i)=n_1(et(i),T,mdn1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+-Rhp(i)*((sigp(i))^2))/((sig(i))^2);

%% Error Calculation
Er55(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;                            
y55=y55+Er55(i);

end
 Error55(r55)=y55/no;
   X55(r55)= a;
  r55=r55+1;
  
figure(cy*1000+5*100)
  hold on
      plot(a,y55/no,'o')
      hold off
 
end

  [Min55, i55dx]= min(Error55);
     a_11= X55(i55dx);
     
    fprintf('value of a_11: %d\n',a_11);
    fprintf('value of ae: %d\n', ae);
    fprintf('value of as: %d\n',as);

        if (round(a_11,8) <round(ae,8) && round(a_11,8) > round(as,8))==true 
            break;  
        else
            ae=a_11+4*Xa;
            as=a_11-4*Xa;
        end        
     
end

%% -----------------------------*()-----------------------------------*()----------------------------     

for a=a_11-Xa : Xa/10 : a_11+Xa;  %% { Loop 2 Fine Grid }
Nd=Nd1; 
mdn1= mdn1_1*m;  
Edefn1=Edefn1_1*e;
Eg0=Eg0_1;
y5=0;

for i=1:37;
T=data(i,1); 

%% Charge Balance Equation (Nd=n-p)
ND=@(eta)n_1(eta,T,mdn1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Two Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Two Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values  
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Two Band System
n1(i)=n_1(et(i),T,mdn1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+-Rhp(i)*((sigp(i))^2))/((sig(i))^2);


 %% Error Calculation
 Er5(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;                            
 y5=y5+Er5(i);

end
 Error5(r5)=y5/no;
   X5(r5)= a;
  r5=r5+1;
figure(cy*100+5)
  hold on
      plot(a,y5/no,'o')
      hold off
 
end

  [Min5, i5dx]= min(Error5);
    a_1= X5(i5dx); 
      

%% *************0**************0*************0************0************0*****************0
%% 6.V.B. DOS effective Mass _mdp_ optimization  
%% *************0**************0*************0************0************0*****************0   
Xmp=(mdp/100)/2;    %[Step size for coarse grid]
mdps=(mdp-5*Xmp);   %[Starting value for coarse grid] 
mdpe=(mdp+5*Xmp);   %[End value for coarse grid]

for fa=1:1:100000 
for mdp=mdps:Xmp:mdpe    %% {Loop1 Coarse Grid}
Nd=Nd1; 
mdn1= mdn1_1*m;  
Edefn1=Edefn1_1*e;
Eg0=Eg0_1;
a=a_1;
y66=0;

for i=1:37;
T=data(i,1);   

%% Charge Balance Equation (Nd=n-p)
ND=@(eta)n_1(eta,T,mdn1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Two Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Two Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values  
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Two Band System
n1(i)=n_1(et(i),T,mdn1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+-Rhp(i)*((sigp(i))^2))/((sig(i))^2);
 
 %% Error Calculation
 Er66(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;
 y66=y66+Er66(i);

end

 Error66(r66)=y66/no;
   X66(r66)=mdp/m;
  r66=r66+1;
figure(cy*1000+6*100)
  hold on
      plot(mdp/m,y66/no,'o')
      hold off
end
   
  [Min66 i66dx]= min(Error66);
   mdp_11= X66(i66dx)*m;
   
     fprintf('value of mdp_11: %d\n', mdp_11);
    fprintf('value of mdpe: %d\n', mdpe);
    fprintf('value of mdps: %d\n', mdps);
    
        if (round(mdp_11/m,8) > round( mdps/m,8) && round(mdp_11/m,8) < round(mdpe/m,8))== true;
            break;
        else
            mdpe=mdp_11+4*Xmp;
            mdps=mdp_11-4*Xmp;
            
        end
end     
%% ------------------------------*()----------------------------------*()-----------------------------    
 
for mdp=mdp_11-Xmp:Xmp/20:mdp_11+Xmp   %% (Loop 2 Fine Grid )
Nd=Nd1; 
mdn1= mdn1_1*m;  
Edefn1=Edefn1_1*e;
Eg0=Eg0_1;
a=a_1;
y6=0;

for i=1:37;
T=data(i,1);  

%% Charge Balance Equation (Nd=n-p)
ND=@(eta)n_1(eta,T,mdn1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Two Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Two Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values  
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Two Band System
n1(i)=n_1(et(i),T,mdn1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+-Rhp(i)*((sigp(i))^2))/((sig(i))^2);
 
 %% Error Calculation
 Er6(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;
 y6=y6+Er6(i);

end

 Error6(r6)=y6/no;
   X6(r6)=mdp/m;
  r6=r6+1;
figure(cy*100+6)
  hold on
      plot(mdp/m,y6/no,'o')
      hold off
end
[Min6 i6dx]= min(Error6);
    mdp_1= X6(i6dx);

%% *************0**************0*************0************0************0*****************0
%%  7.Deformation Potential Valence Band _Edefp_Optimization  
%% *************0**************0*************0************0************0*****************0
Xp=(Edefp/150)/2;       %[Step size for coarse grid]
Edefps=(Edefp-5*Xp);    %[Starting value for coarse grid] 
Edefpe=(Edefp+5*Xp);    %[End value for coarse grid]

for fa7=1:1:100000
for Edefp= Edefps :Xp : Edefpe;    %% {Loop1 Coarse Grid}    
Nd=Nd1; 
mdn1= mdn1_1*m;  
Edefn1=Edefn1_1*e;
Eg0=Eg0_1;
a=a_1;
mdp= mdp_1*m;  
y77=0;

for i=1:37;
T=data(i,1);    

%% Charge Balance Equation (Nd=n-p)
ND=@(eta)n_1(eta,T,mdn1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Two Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Two Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values  
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Two Band System
n1(i)=n_1(et(i),T,mdn1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+-Rhp(i)*((sigp(i))^2))/((sig(i))^2);


 %% Error Calculation
 Er77(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;                            
 y77=y77+Er77(i);

end
 Error77(r77)=y77/no;
   X77(r77)=Edefp/e;
  r77=r77+1;
figure(cy*1000+7*100)
  hold on
      plot(Edefp/e,y77/no,'o')
      hold off
end
    [Min77 i77dx]= min(Error77);
    Edefp_11= X77(i77dx)*e;
    
    fprintf('value of Edefp_11: %d\n', Edefp_11);
    fprintf('value of Edefpe: %d\n', Edefpe);
    fprintf('value of Edefps: %d\n', Edefps);
           if ( round(Edefp_11/e, 8) > round(Edefps/e,8) && round( Edefp_11/e, 8) < round(Edefpe/e ,8))==true
                break;
           else
                Edefpe=Edefp_11+4*Xp;
                Edefps=Edefp_11-4*Xp;
            
           end
    
end    
%% -------------------------*()-----------------------------------*()--------------------------------
for Edefp=Edefp_11-Xp :Xp/10 : Edefp_11+Xp   %% { Loop 2 Fine Grid }
Nd=Nd1; 
mdn1= mdn1_1*m;  
Edefn1=Edefn1_1*e;
Eg0=Eg0_1;
a=a_1;
mdp= mdp_1*m;      
y7=0;

for i=1:37;
T=data(i,1);   

%% Charge Balance Equation (Nd=n-p)
ND=@(eta)n_1(eta,T,mdn1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Two Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Two Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values  
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Two Band System
n1(i)=n_1(et(i),T,mdn1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+-Rhp(i)*((sigp(i))^2))/((sig(i))^2);

%% Error Calculation
 Er7(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;                            
 y7=y7+Er7(i);

end
 Error7(r7)=y7/no;
 X7(r7)=Edefp/e;
 r7=r7+1;
figure(cy*100+7)
  hold on
      plot(Edefp/e,y7/no,'o')
      hold off
end
    [Min7 i7dx]= min(Error7);
    Edefp_1= X7(i7dx);      
    
 
%% *************0**************0*************0************0************0*****************0
%% 8.grain size_L_ optimization 
%% *************0**************0*************0************0************0*****************0
XL=(L/10)/2       %[Step size for coarse grid]
Ls=(L-5*XL)       %[Starting value for coarse grid] 
Le=(L+5*XL)       %[End value for coarse grid]
for fa11=1:1:100000
 for L =  Ls : XL : Le; %% {Loop1 Coarse Grid}      
Nd=Nd1;
mdn1=mdn1_1*m; 
Edefn1=Edefn1_1*e;
mdp= mdp_1*m;  
Edefp=Edefp_1*e;
Eg0=Eg0_1;
a=a_1;

y99=0;

for i=1:37;
T=data(i,1);    

%% Charge Balance Equation (Nd=n-p)
ND=@(eta)n_1(eta,T,mdn1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Two Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Two Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values  
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Two Band System
n1(i)=n_1(et(i),T,mdn1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+-Rhp(i)*((sigp(i))^2))/((sig(i))^2);


 %% Error Calculation
 Er99(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;                            
 y99=y99+Er99(i);

end
 Error99(r99)=y99/no;
   X99(r99)=L;
  r99=r99+1;
figure(cy*1000+9*100)
  hold on
      plot(L,y99/no,'o')
      hold off
end
    [Min99 i99dx]= min(Error99);
    L_11= X99(i99dx);

    fprintf('value of L_11: %d\n', L_11);
    fprintf('value of Le: %d\n', Le);
    fprintf('value of Ls: %d\n', Ls);
    
            if (round(L_11,8) > round(Ls,8) && round(L_11,8) < round(Le,8))== true
                break;
            else
                Le=L_11+4*XL;
                Ls=L_11-4*XL;
            
            end

end     
 
%%----------------------------*()---------------------------------*()------------------------------------------

for L=(L_11-XL): XL/20 : (L_11+XL);   %% {Loop 2 Fine Grid}
Nd=Nd1;
mdn1=mdn1_1*m; 
Edefn1=Edefn1_1*e
Eg0=Eg0_1;
a=a_1;
mdp= mdp_1*m;  
Edefp=Edefp_1*e;
y9=0;

for i=1:37;
T=data(i,1);

%% Charge Balance Equation (Nd=n-p)
ND=@(eta)n_1(eta,T,mdn1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Two Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Two Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values  
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Two Band System
n1(i)=n_1(et(i),T,mdn1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+-Rhp(i)*((sigp(i))^2))/((sig(i))^2);

%% Error Calculation
Er9(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;                            
y9=y9+Er9(i);

end
 Error9(r9)=y9/no;
 X9(r9)=L;
 r9=r9+1;
figure(cy*100+9)
  hold on
  plot(L,y9/no,'o')
  hold off
end
 [Min9 i9dx]= min(Error9);
 L_1= X9(i9dx);   
 
 
 
%% *************0**************0*************0************0************0*****************0
%% 9.Grain Boundary Potential Barrier  _Eb_  optimization 
%% *************0**************0*************0************0************0*****************0
Xeb=(Eb/10)/2;      %[Step size for coarse grid]
Ebs=(Eb-5*Xeb);     %[Starting value for coarse grid] 
Ebe=(Eb+5*Xeb);     %[End value for coarse grid]   
for fa10=1:1:100000
 for Eb =  Ebs : Xeb : Ebe;     %% {Loop1 Coarse Grid}  
Nd=Nd1; 
mdn1= mdn1_1*m;  
Edefn1=Edefn1_1*e;
Eg0=Eg0_1;
a=a_1;
mdp= mdp_1*m; 
Edefp=Edefp_1*e;
y88=0;
L=L_1
for i=1:37;
T=data(i,1); 

%% Charge Balance Equation (Nd=n-p)
ND=@(eta)n_1(eta,T,mdn1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Two Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Two Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values  
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Two Band System
n1(i)=n_1(et(i),T,mdn1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+-Rhp(i)*((sigp(i))^2))/((sig(i))^2);


 %% Error Calculation
 Er88(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;                            
 y88=y88+Er88(i);

end
 Error88(r88)=y88/no;
   X88(r88)=Eb;
  r88=r88+1;
figure(cy*1000+8*100)
  hold on
      plot(Eb,y88/no,'o')
      hold off
end
    [Min88 i88dx]= min(Error88);
    Eb_11= X88(i88dx);

    fprintf('value of Eb_11: %d\n', Eb_11);
    fprintf('value of Ebe: %d\n', Ebe);
    fprintf('value of Ebs: %d\n', Ebs);
            if (round(Eb_11,8) > round(Ebs,8) && round(Eb_11,8) < round(Ebe,8))== true
                break;
            else
                Ebe=Eb_11+4*Xeb;
                Ebs=Eb_11-4*Xeb;
            
            end

end     
 
%% ----------------------------*()---------------------------------*()------------------------------------------

for Eb=(Eb_11-Xeb): Xeb/20 : (Eb_11+Xeb);   %% { Loop 2 Fine Grid }
Nd=Nd1; 
mdn1= mdn1_1*m;  
Edefn1=Edefn1_1*e;
Eg0=Eg0_1;
a=a_1;
mdp= mdp_1*m; 
Edefp=Edefp_1*e;
L=L_1
y8=0;

for i=1:37;
T=data(i,1);    

%% Charge Balance Equation (Nd=n-p)
ND=@(eta)n_1(eta,T,mdn1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Two Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Two Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values  
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Two Band System
n1(i)=n_1(et(i),T,mdn1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+-Rhp(i)*((sigp(i))^2))/((sig(i))^2);


%% Error Calculation
Er8(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;                            
y8=y8+Er8(i);

end
 Error8(r8)=y8/no;
 X10(r8)=Eb;
 r8=r8+1;
figure(cy*100+8)
  hold on
  plot(Eb,y8/no,'o')
  hold off
end
 [Min8 i8dx]= min(Error8);
 Eb_1= X10(i8dx);   
 
 
 
%% =====================================================  
%% Output excel file generation for optimized parameters  
%% =====================================================
 store(1,cy)=Nd1;
 store(2,cy)=mdn1_1;
 store(3,cy)=Edefn1_1;
 store(4,cy)=Eg0_1;
 store(5,cy)=a_1;
 store(6,cy)=mdp_1;
 store(7,cy)=Edefp_1;
 store(8,cy)=Eb_1;
 store(9,cy)=L_1;
 store(10,cy)=Min8;

xlswrite('Parameter_File.xlsx',store)

end