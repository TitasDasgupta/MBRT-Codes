close all
clear all

%% ------------------------------------------------------------------------------------------------------------------------------
%% MBRT Code (EBS Model: 2 Conduction Bands & 1 Valence Band, Scattering Mechanism: Acoustic Phonon and Grain Boundary Scattering of charge carriers)
%% Example File: Doped Mg2Si (experimental data file:Experimental_Data_Mg2Si_doped.xlsx, Guess Values File:Parameter_File.xlsx )   


%% Universal Constants 
kb=1.3807e-23; e=1.60219e-19; m=9.1095e-31; h=6.6262e-34;hbar=1.054571e-34;
k=8.617e-5;

%% ------------------------------------------------------------------------------------
%% Input File Information
data=xlsread('Experimental_Data_Mg2Si_doped.xlsx'); % Input file for S,sigma,RH
store=xlsread('Parameter_File.xlsx'); %File to store the variables after each cycle    

no=37; % User defined number of temperature points 


%% ------------------
%% Material Constants
%% ------------------

vL=7680; % Velocity of sound in Mg2Si       
d=1920; % density of Mg2Si 

%% -------------------
%% Degeneracy of Bands
%% -------------------

Nvn1 =3;  % Degeneracy of 1st conduction band at X point
Nvn2 =3;  % Degeneracy of 2nd conduction band at X point
Nvp  =2;  % Degeneracy of valence band at gamma point

%% -----------------------
%% Valence Band Parameters
%% ----------------------- 
mdp_= 1.8  ; %% Valence band DOS efffective mass
Edefp_=10.4; %% Valence band Deformation Potential


%% -----------------------------
%% Function Declaration 
%% -----------------------------

%% Fermi Integral
% Fermi Integrand 
FI=@(ene,eta,j)(ene.^j)./(1+exp(ene-eta));
% Fermi Integral
F=@(eta,j)quadgk(@(ene)FI(ene,eta,j),0,inf);
%% ------------------------------

%% ------------------------------
%% Interband Seperation 
E1=@(E1_0,T,d1) (E1_0 + d1*T)/(k*T);
%% ------------------------------

%% ------------------------------
%% Band Gap
Eg=@(T,a,Eg0)(Eg0-a*T)/(k*T);

%% Valence Band Parameter 
mdp=mdp_*m;
Edefp=Edefp_*e;

%% Single Valley Mass
mn1s=@(mdn1)mdn1/(Nvn1^(2/3));
mn2s=@(mdn2)(mdn2)/(Nvn2^(2/3));
mps=@(mdp)(mdp)/(Nvp^(2/3));


%% ---------------------------
%% Charge Transport Properties
%% ---------------------------

%% Charge Carrier Concentration (individual Band)
n_1=@(eta,T,mdn1) 4*pi*((2*mdn1*kb*T/(h*h))^(1.5))*F(eta,0.5);
n_2=@(eta,T,mdn2,E1_0,d1) 4*pi*((2*mdn2*kb*T/(h*h))^(1.5))*F(eta-E1(E1_0,T,d1),0.5);
n_p=@(eta,T,a,mdp,Eg0) 4*pi*((2*mdp*kb*T/(h*h))^(1.5))*F(-eta-Eg(T,a,Eg0),0.5);


%% Free Mobility Function_Acoustic Phonon Scattering (individual band)
mu0n1_ap=@(T,Edefn1,mdn1)(e*pi*(hbar^4)*(vL^2)*d)/((sqrt(2))*(Edefn1^2)*((mn1s(mdn1)*kb*T)^1.5)*mn1s(mdn1));
mu0n2_ap=@(T,Edefn2,mdn2)(e*pi*(hbar^4)*(vL^2)*d)/((sqrt(2))*(Edefn2^2)*((mn2s(mdn2)*kb*T)^1.5)*mn2s(mdn2));
mu0p_ap=@(T,Edefp,mdp)(e*pi*(hbar^4)*(vL^2)*d)/((sqrt(2))*(Edefp^2)*((mps(mdp)*kb*T)^1.5)*mps(mdp));


%% Free Mobility Function_Grain Boundary Scattering (individual band)
mu0n1_gb=@(T,Eb,mdn1,L)(L*e*(2*pi*mn1s(mdn1)*kb*T)^(-0.5)*exp(-Eb/(k*T)));
mu0n2_gb=@(T,Eb,mdn2,L,E1_0,d1)(L*e*(2*pi*mn2s(mdn2)*kb*T)^(-0.5)*exp(-Eb/(k*T)+E1(E1_0,T,d1)));
mu0p_gb=@(T,Eb,mdp,L,a,Eg0)(L*e*(2*pi*mps(mdp)*kb*T)^(-0.5)*exp(Eb/(k*T)+Eg(T,a,Eg0)));

%% Free Mobility Function_TOTAL (individual Band)
mu0n1 = @(T,Edefn1,mdn1,Eb,L)((mu0n1_ap(T,Edefn1,mdn1))^(-1) +(mu0n1_gb(T,Eb,mdn1,L))^(-1) )^(-1);
mu0n2 = @(T,Edefn2,mdn2,Eb,L, E1_0,d1)((mu0n2_ap(T,Edefn2,mdn2))^(-1) +(mu0n2_gb(T,Eb,mdn2,L,E1_0,d1))^(-1))^(-1);
mu0p = @(T,Edefp,mdp,Eb,L,a,Eg0)((mu0p_ap(T,Edefp,mdp))^(-1) + (mu0p_gb(T,Eb,mdp,L,a,Eg0))^(-1))^(-1);


%% Electrical Conductivity (individual band) 
sig_n1=@(eta,T,Edefn1,mdn1,Eb,L)(8*pi*e/(3*h^3))*mu0n1(T,Edefn1,mdn1,Eb,L)*Nvn1*((2*mn1s(mdn1)*kb*T)^1.5)*F(eta,0);
sig_n2=@(eta,T,Edefn2,mdn2,E1_0,d1,Eb,L)(8*pi*e/(3*h^3))*mu0n2(T,Edefn2,mdn2,Eb,L,E1_0,d1)*Nvn2*((2*mn2s(mdn2)*kb*T)^1.5)*F(eta-E1(E1_0,T,d1),0);
sig_p=@(eta,T,Edefp,mdp,a,Eg0,Eb,L)(8*pi*e/(3*h^3))*mu0p(T,Edefp,mdp,Eb,L,a,Eg0)*Nvp*((2*mps(mdp)*kb*T)^1.5)*F(-eta-Eg(T,a,Eg0),0);

%% Seebeck Coefficient (individual band)
Sbk_n1=@(eta)-(kb/e)*((2*F(eta,1)/F(eta,0))-eta);
Sbk_n2=@(eta,E1_0,T,d1)-(kb/e)*((2*F(eta-E1(E1_0,T,d1),1)/F(eta-E1(E1_0,T,d1),0))-(eta-E1(E1_0,T,d1)));
Sbk_p=@(eta,T,a,Eg0)-(kb/e)*((2*F(-eta-Eg(T,a,Eg0),1)/F(-eta-Eg(T,a,Eg0),0))-(-eta-Eg(T,a,Eg0)));

%% Hall Prefactor (rH) (individual band)
rH_n1= @(eta) 1.5*F(eta,0.5)*F(eta,-0.5)/(2*F(eta,0)*F(eta,0));
rH_n2= @(eta,E1_0,T,d1) 1.5*F(eta-E1(E1_0,T,d1),0.5)*F(eta-E1(E1_0,T,d1),-0.5)/(2*F(eta-E1(E1_0,T,d1),0)*F(eta-E1(E1_0,T,d1),0));
rH_p= @(eta,T,a,Eg0) 1.5*F(-eta-Eg(T,a,Eg0),0.5)*F(-eta-Eg(T,a,Eg0),-0.5)/(2*F(-eta-Eg(T,a,Eg0),0)*F(-eta-Eg(T,a,Eg0),0));
%% -----------------------------------------------------------------------------------------------------------------------
    

for cy=2:1:50   %(User defined number of refinement cycles )
    
   Nd1= store(1,cy-1);       % Donor concentration 
   E1_0= store(2,cy-1);      % Interband separation at zero Kelvin   
   d1=  store(3,cy-1);       % Interband separation temperature constant 
   mdn2=store(4,cy-1)*m;     % DOS mass of 2nd conduction band   
   Edefn2=store(5,cy-1)*e;   % Deformation potential of 2nd conduction band 
   Eg0=store(6,cy-1);        % Band gap at zero Kelvin                           
   a=store(7,cy-1);          % Band gap temperature constant   
   mdn1= store(8,cy-1)*m;    % DOS mass of 1st conduction band                              
   Edefn1= store(9,cy-1)*e;  % Deformation potential of 1st conduction band 
   Eb= store(10,cy-1);       % Grain Boundary Barrier Activation Potential
   L=store(11,cy-1);         % Grain Size
            

%%  Index for Error array calculation for each refinement loop [Coarse and fine grids]
r1=1;
r11=1;
r2=1;
r22=1;
r3=1;
r33=1;
r4=1;
r44=1;
r5=1;
r55=1;
r6=1;
r66=1;
r7=1;
r77=1;
r8=1;
r88=1;
r9=1;
r99=1;
r91=1;
r991=1;
r92=1;
r992=1;
r10=1;
r1010=1;
r11=1;
r1111=1;


%% *************0**************0*************0************0************0*****************0
%% 1.Donor concentration optimization
%% *************0**************0*************0************0************0*****************0
X=(Nd1/2)/2;  %[Step size for coarse grid]
Ns=(Nd1-4*X); %[Starting value for coarse grid] 
Ne=(Nd1+4*X); %[End value for coarse grid]

for fa=2:2:100 %[Maximum number of trials to reach minima]
for Nd= Ns :X: Ne; %% {Loop 1 Coarse Grid}
y11=0;  % counter

 for i=1:37;
T=data(i,1);    
%% Charge Balance Equation (Nd=n1+n2-p)

ND=@(eta)n_1(eta,T,mdn1)+n_2(eta,T,mdn2,E1_0,d1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Three Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sign2(i)=sig_n2(et(i),T,Edefn2,mdn2,E1_0,d1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sign2(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Three Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkn2(i)= Sbk_n2(et(i),E1_0,T,d1);
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)+Sbkn2(i)*sign2(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Three Band System
n1(i)=n_1(et(i),T,mdn1);
n2(i)=n_2(et(i),T,mdn2,E1_0,d1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHn2(i)= rH_n2(et(i),E1_0,T,d1);
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhn2(i)=rHn2(i)/(e*n2(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+Rhn2(i)*((sign2(i))^2)-Rhp(i)*((sigp(i))^2))/((sig(i))^2);

 %% Error Calculation
 Er11(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;
 y11=y11+Er11(i);

end
  Error11(r11)=y11/no;
   X11(r11)=Nd;
  r11=r11+1;
  
figure(cy*1000+1*100)
  hold on
      plot(Nd,y11/no,'o')
      hold off
end 
  [Min11, i11dx]= min(Error11);
    Nd11= X11(i11dx);
   fprintf('value of Nd11: %d\n', Nd11);
    fprintf('value of Ne: %d\n', Ne);
    fprintf('value of Ns: %d\n', Ns);
   
        if (round (Nd11,8) > round(Ns,8) && round (Nd11,8)< round(Ne,8))== true
             break;  
        else
            X=(Nd11/2)/2;
            Ne=Nd11+4*X;
            Ns=Nd11-4*X;
           
        end
end   
%% -------------------------------*()------------------------------------*()---------------------------- 
%% for  Nd= Nd11-X:X/10:Nd11+X;  
 for Nd= Nd11-X:X/10:Nd11+X; %% (LOOP 2-Finer Grid, Smaller Range)
  y1=0;   
for i=1:37;
T=data(i,1);    
%% Charge Balance Equation (Nd=n1+n2-p)
ND=@(eta)n_1(eta,T,mdn1)+n_2(eta,T,mdn2,E1_0,d1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Three Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sign2(i)=sig_n2(et(i),T,Edefn2,mdn2,E1_0,d1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sign2(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Three Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkn2(i)= Sbk_n2(et(i),E1_0,T,d1);
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)+Sbkn2(i)*sign2(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Three Band System
n1(i)=n_1(et(i),T,mdn1);
n2(i)=n_2(et(i),T,mdn2,E1_0,d1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHn2(i)= rH_n2(et(i),E1_0,T,d1);
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhn2(i)=rHn2(i)/(e*n2(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+Rhn2(i)*((sign2(i))^2)-Rhp(i)*((sigp(i))^2))/((sig(i))^2);



%% Error Calculation
 Er1(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;
 y1=y1+Er1(i);


end
  Error1(r1)=y1/no;
   X1(r1)=Nd;
  r1=r1+1;
  
figure(cy*100+1)
  hold on
      plot(Nd,y1/no,'o')
      hold off
end
  [Min1 ,i1dx]= min(Error1);
    Nd1= X1(i1dx);
    
%% *************0**************0*************0************0************0*****************0
%% 2.Band Seperation at Zero Kelvin _E1_0_ optimization    
%% *************0**************0*************0************0************0*****************0
Xe=(E1_0/20)/2;
E1s=(E1_0-4*Xe);
E1e=(E1_0+4*Xe);

for fa1=1:1:100
    
for E1_0=E1s:Xe:E1e;   %% { Loop1 Coarse Grid }
    Nd=Nd1;
    y22=0;
for i=1:37;
 T=data(i,1);     
%% Charge Balance Equation (Nd=n1+n2-p)
ND=@(eta)n_1(eta,T,mdn1)+n_2(eta,T,mdn2,E1_0,d1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Three Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sign2(i)=sig_n2(et(i),T,Edefn2,mdn2,E1_0,d1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sign2(i)+sigp(i)
 
%% Calculate Seebeck Coefficient  for Three Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkn2(i)= Sbk_n2(et(i),E1_0,T,d1);
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)+Sbkn2(i)*sign2(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Three Band System
n1(i)=n_1(et(i),T,mdn1);
n2(i)=n_2(et(i),T,mdn2,E1_0,d1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHn2(i)= rH_n2(et(i),E1_0,T,d1);
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhn2(i)=rHn2(i)/(e*n2(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+Rhn2(i)*((sign2(i))^2)-Rhp(i)*((sigp(i))^2))/((sig(i))^2);


%% Error Calculation
 Er22(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;
 y22=y22+Er22(i);

end

 Error22(r22)=y22/no;
   X22(r22)=E1_0;
  r22=r22+1;
  figure(cy*1000+2*100)
  hold on
      plot(E1_0,y22/no,'o')
  hold off
end  %% {Loop 1 large range and larger step size}

[Min22 i22dx]= min(Error22);
   E1_011= X22(i22dx); 
   
      fprintf('value of E1_011: %d\n',E1_011);
    fprintf('value of E1e: %d\n', E1e);
    fprintf('value of E1s: %d\n',E1s);
    
        if (round (abs(E1_011),8) < round (abs(E1e),8) && round (abs(E1_011),8) > round(abs(E1s),8) )==true
            break;  
        else
            Xe=E1_011/40
            E1e=E1_011+4*Xe;
            E1s=E1_011-4*Xe;
        end
   

end 
%% ------------------------------*()------------------------------------*()----------------------------     
for E1_0=(E1_011-Xe):Xe/10:(E1_011+Xe);  % ( Loop 2 Fine Grid) 
    Nd=Nd1;
    y2=0;
    
for i=1:37;
T=data(i,1);       
%% Charge Balance Equation (Nd=n1+n2-p)
ND=@(eta)n_1(eta,T,mdn1)+n_2(eta,T,mdn2,E1_0,d1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Three Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sign2(i)=sig_n2(et(i),T,Edefn2,mdn2,E1_0,d1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sign2(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Three Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkn2(i)= Sbk_n2(et(i),E1_0,T,d1);
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)+Sbkn2(i)*sign2(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Three Band System
n1(i)=n_1(et(i),T,mdn1);
n2(i)=n_2(et(i),T,mdn2,E1_0,d1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHn2(i)= rH_n2(et(i),E1_0,T,d1);
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhn2(i)=rHn2(i)/(e*n2(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+Rhn2(i)*((sign2(i))^2)-Rhp(i)*((sigp(i))^2))/((sig(i))^2);

%% Error Calculation
 Er2(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;
 y2=y2+Er2(i);

end

 Error2(r2)=y2/no;
   X2(r2)=E1_0;
  r2=r2+1;
  figure(cy*100+2)
  hold on
      plot(E1_0,y2/no,'o')
  hold off
end

[Min2,i2dx]= min(Error2);
   E1_01= X2(i2dx)   ;
   
   
%% *************0**************0*************0************0************0*****************0************
%% 3.Interband Seperation Temperature Constant _d1_optimization  
%% *************0**************0*************0************0************0*****************0************   
Xd=(d1/5);
ds=(d1-Xd);
de=(d1+Xd);

for fa=1:1:100000        
for d1=ds:Xd/10:de;    %% { Loop1 Coarse Grid }
Nd=Nd1;
E1_0=E1_01;
y33=0; 

for i=1:37
T=data(i,1);    

%% Charge Balance Equation (Nd=n1+n2-p)
ND=@(eta)n_1(eta,T,mdn1)+n_2(eta,T,mdn2,E1_0,d1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Three Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sign2(i)=sig_n2(et(i),T,Edefn2,mdn2,E1_0,d1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sign2(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Three Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkn2(i)= Sbk_n2(et(i),E1_0,T,d1);
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)+Sbkn2(i)*sign2(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Three Band System
n1(i)=n_1(et(i),T,mdn1);
n2(i)=n_2(et(i),T,mdn2,E1_0,d1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHn2(i)= rH_n2(et(i),E1_0,T,d1);
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhn2(i)=rHn2(i)/(e*n2(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+Rhn2(i)*((sign2(i))^2)-Rhp(i)*((sigp(i))^2))/((sig(i))^2);

%% Error Calculation
Er33(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;                            
y33=y33+Er33(i);

end
 Error33(r33)=y33/no;
   X33(r33)= d1;
  r33=r33+1;
  
figure(cy*1000+3*100)
  hold on
      plot(d1,y33/no,'o')
      hold off
 
end

  [Min33, i33dx]= min(Error33);
    d1_11= round(X33(i33dx), 6, "significant")
        
     fprintf('value of d1_11: %d\n',d1_11);
     fprintf('value of de: %d\n', de);
     fprintf('value of ds: %d\n',ds);

        if (round(d1_11,10)< round(de,10) && round(d1_11,10) > round(ds,10) )== true
            break;  
        else
            Xd=(d1_11/20);
            de=d1_11+Xd;
            ds=d1_11-Xd;
        end    
    

end  

%% --------------------------------*()-----------------------------------*()------------------------------*()------------------------*()----------------
for d1=d1_11-Xd/10:Xd/100:d1_11+Xd/10;  %% {Loop 2 Fine Grid }
Nd=Nd1;
E1_0=E1_01;
y3=0;

for i=1:37
T=data(i,1);    
%% Charge Balance Equation (Nd=n1+n2-p)
ND=@(eta)n_1(eta,T,mdn1)+n_2(eta,T,mdn2,E1_0,d1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Three Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sign2(i)=sig_n2(et(i),T,Edefn2,mdn2,E1_0,d1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sign2(i)+sigp(i)
 
%% Calculate Seebeck Coefficient  for Three Band System
Sbkn1(i)=Sbk_n1(et(i))               
Sbkn2(i)= Sbk_n2(et(i),E1_0,T,d1)
Sbkp(i)=Sbk_p(et(i),T,a,Eg0)
Sbk(i)=(Sbkn1(i)*sign1(i)+Sbkn2(i)*sign2(i)-Sbkp(i)*sigp(i))/sig(i)

%% Read Experimental Values
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Three Band System
n1(i)=n_1(et(i),T,mdn1);
n2(i)=n_2(et(i),T,mdn2,E1_0,d1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHn2(i)= rH_n2(et(i),E1_0,T,d1);
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhn2(i)=rHn2(i)/(e*n2(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+Rhn2(i)*((sign2(i))^2)-Rhp(i)*((sigp(i))^2))/((sig(i))^2)


 %% Error Calculation
 Er3(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;                            
 y3=y3+Er3(i);

end
 Error3(r3)=y3/no;
   X3(r3)= d1;
  r3=r3+1;
figure(cy*100+3)
  hold on
      plot(d1,y3/no,'o')
      hold off
 
end

  [Min3, i3dx]= min(Error3);
    d1_1= X3(i3dx); 
    
%% *************0**************0*************0************0************0*****************0************  
%% 4.CB2 DOS Effective Mass_mdn2_ optimization  
%% *************0**************0*************0************0************0*****************0************  

Xm2=(mdn2/100)/2;
mdn2s=(mdn2-5*Xm2);
mdn2e=(mdn2+5*Xm2);

for fa=1:1:100000 
for mdn2=mdn2s:Xm2:mdn2e    %%  { Loop1 Coarse Grid }
Nd=Nd1;
E1_0=E1_01;
d1=d1_1;
y44=0;

for i=1:37
T=data(i,1);    

%% Charge Balance Equation (Nd=n1+n2-p)
ND=@(eta)n_1(eta,T,mdn1)+n_2(eta,T,mdn2,E1_0,d1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Sigma for Three band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sign2(i)=sig_n2(et(i),T,Edefn2,mdn2,E1_0,d1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sign2(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Three Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkn2(i)= Sbk_n2(et(i),E1_0,T,d1);
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)+Sbkn2(i)*sign2(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Three Band System
n1(i)=n_1(et(i),T,mdn1);
n2(i)=n_2(et(i),T,mdn2,E1_0,d1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHn2(i)= rH_n2(et(i),E1_0,T,d1);
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhn2(i)=rHn2(i)/(e*n2(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+Rhn2(i)*((sign2(i))^2)-Rhp(i)*((sigp(i))^2))/((sig(i))^2);
 
 %% Error Calculation
 Er44(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;
 y44=y44+Er44(i);

end

 Error44(r44)=y44/no;
   X44(r44)=mdn2/m;
  r44=r44+1;
figure(cy*1000+4*100)
  hold on
      plot(mdn2/m,y44/no,'o')
      hold off
end
   
  [Min44 i44dx]= min(Error44);
   mdn2_11= X44(i44dx)*m;
   
     fprintf('value of mdn2_11: %d\n', mdn2_11);
    fprintf('value of mdn2e: %d\n', mdn2e);
    fprintf('value of mdn2s: %d\n', mdn2s);
    
        if (round(mdn2_11/m,5) > round( mdn2s/m,5) && round(mdn2_11/m,5) < round(mdn2e/m,5))== true;
            break;
        else
            mdn2e=mdn2_11+4*Xm2;
            mdn2s=mdn2_11-4*Xm2;
            
        end
end     
%% ------------------------------*()----------------------------------*()-----------------------------    
 
for mdn2=mdn2_11-Xm2:Xm2/20:mdn2_11+Xm2   %% {Lop 2 Fine Grid}
Nd=Nd1;
E1_0=E1_01;
d1=d1_1;
y4=0;

for i=1:37
T=data(i,1);    
%% Charge Balance Equation (Nd=n1+n2-p)
ND=@(eta)n_1(eta,T,mdn1)+n_2(eta,T,mdn2,E1_0,d1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Three Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sign2(i)=sig_n2(et(i),T,Edefn2,mdn2,E1_0,d1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sign2(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Three Band System
Sbkn1(i)=Sbk_n1(et(i));             
Sbkn2(i)= Sbk_n2(et(i),E1_0,T,d1);
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)+Sbkn2(i)*sign2(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Three Band System
n1(i)=n_1(et(i),T,mdn1);
n2(i)=n_2(et(i),T,mdn2,E1_0,d1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHn2(i)= rH_n2(et(i),E1_0,T,d1);
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhn2(i)=rHn2(i)/(e*n2(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+Rhn2(i)*((sign2(i))^2)-Rhp(i)*((sigp(i))^2))/((sig(i))^2);

 
 %% Error Calculation
 Er4(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;
 y4=y4+Er4(i);

end

 Error4(r4)=y4/no;
   X4(r4)=mdn2/m;
  r4=r4+1;
figure(cy*100+4)
  hold on
      plot(mdn2/m,y4/no,'o')
      hold off
end
[Min4 i4dx]= min(Error4);
    mdn2_1= X4(i4dx);

%% *************0**************0*************0************0************0*****************0************  
%%  5.Deformation Potential Conduction Band 2_Edefn2_Optimization  
%% *************0**************0*************0************0************0*****************0************
Xe2=(Edefn2/150)/2;
Edefn2s=(Edefn2-5*Xe2);
Edefn2e=(Edefn2+5*Xe2);

for fa1=1:1:100000
for Edefn2= Edefn2s :Xe2 : Edefn2e;    %% { Loop1 Coarse Grid }    
Nd=Nd1;
E1_0=E1_01;
d1=d1_1; 
mdn2= mdn2_1*m;  
y55=0;

for i=1:37
 T=data(i,1);  
%% Charge Balance Equation (Nd=n1+n2-p)
ND=@(eta)n_1(eta,T,mdn1)+n_2(eta,T,mdn2,E1_0,d1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Three Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sign2(i)=sig_n2(et(i),T,Edefn2,mdn2,E1_0,d1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sign2(i)+sigp(i);
 
%% Calculate Seebeck Coefficient for Three Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkn2(i)= Sbk_n2(et(i),E1_0,T,d1);
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)+Sbkn2(i)*sign2(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Three Band System
n1(i)=n_1(et(i),T,mdn1);
n2(i)=n_2(et(i),T,mdn2,E1_0,d1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHn2(i)= rH_n2(et(i),E1_0,T,d1);
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhn2(i)=rHn2(i)/(e*n2(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+Rhn2(i)*((sign2(i))^2)-Rhp(i)*((sigp(i))^2))/((sig(i))^2);


 %% Error Calculation
 Er55(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;                            
 y55=y55+Er55(i);

end
 Error55(r55)=y55/no;
   X55(r55)=Edefn2/e;
  r55=r55+1;
figure(cy*1000+5*100)
  hold on
      plot(Edefn2/e,y55/no,'o')
      hold off
end
    [Min55 i55dx]= min(Error55);
    Edefn2_11= X55(i55dx)*e;
    
    fprintf('value of Edefn2_11: %d\n', Edefn2_11);
    fprintf('value of Edefn2e: %d\n', Edefn2e);
    fprintf('value of Edefn2s: %d\n', Edefn2s);
           if ( round(Edefn2_11/e, 5) > round(Edefn2s/e,5) && round( Edefn2_11/e, 5) < round(Edefn2e/e ,5))==true
                break;
           else
                Edefn2e=Edefn2_11+4*Xe2;
                Edefn2s=Edefn2_11-4*Xe2;
            
           end
    
end    
%% -------------------------*()-----------------------------------*()--------------------------------
for Edefn2=Edefn2_11-Xe2 :Xe2/10 : Edefn2_11+Xe2   %% {Loop 2 Fine Grid}
Nd=Nd1;
E1_0=E1_01;
d1=d1_1; 
mdn2= mdn2_1*m;     
y5=0;

for i=1:37
T=data(i,1);    

%% Charge Balance Equation (Nd=n1+n2-p)
ND=@(eta)n_1(eta,T,mdn1)+n_2(eta,T,mdn2,E1_0,d1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Three Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sign2(i)=sig_n2(et(i),T,Edefn2,mdn2,E1_0,d1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sign2(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Three Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkn2(i)= Sbk_n2(et(i),E1_0,T,d1);
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)+Sbkn2(i)*sign2(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Three Band System
n1(i)=n_1(et(i),T,mdn1);
n2(i)=n_2(et(i),T,mdn2,E1_0,d1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHn2(i)= rH_n2(et(i),E1_0,T,d1);
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhn2(i)=rHn2(i)/(e*n2(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+Rhn2(i)*((sign2(i))^2)-Rhp(i)*((sigp(i))^2))/((sig(i))^2);


%% Error Calculation
 Er5(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;                            
 y5=y5+Er5(i);

end
 Error5(r5)=y5/no;
   X5(r5)=Edefn2/e;
  r5=r5+1;
figure(cy*100+5)
  hold on
      plot(Edefn2/e,y5/no,'o')
      hold off
end
    [Min5 i5dx]= min(Error5);
    Edefn2_1= X5(i5dx);   

%% *************0**************0*************0************0************0*****************0************ 
%% Band Gap parameters kept constant 
%%  *************0**************0*************0************0************0*****************0************ 

      Eg0_1=Eg0;
       a_1= a; 
%% *************0**************0*************0************0************0*****************0************  
%% 6. CB1 DOS Effective Mass_mdn1_ optimization 
%% *************0**************0*************0************0************0*****************0************  
Xm1=(mdn1/100)/2;
mdn1s=(mdn1-5*Xm1);
mdn1e= (mdn1+5*Xm1);

for fa8=1:1:100000 
for mdn1=mdn1s:Xm1:mdn1e     %% { Loop1 Coarse Grid }
Nd=Nd1;
E1_0=E1_01;
d1=d1_1; 
mdn2= mdn2_1*m;  
Edefn2=Edefn2_1*e;
Eg0=Eg0_1;
a=a_1;
y88=0;

for i=1:37
T=data(i,1);    

%% Charge Balance Equation (Nd=n1+n2-p)
ND=@(eta)n_1(eta,T,mdn1)+n_2(eta,T,mdn2,E1_0,d1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Three Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sign2(i)=sig_n2(et(i),T,Edefn2,mdn2,E1_0,d1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sign2(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Three Band System
Sbkn1(i)=Sbk_n1(et(i));              
Sbkn2(i)= Sbk_n2(et(i),E1_0,T,d1);
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)+Sbkn2(i)*sign2(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Three Band System
n1(i)=n_1(et(i),T,mdn1);
n2(i)=n_2(et(i),T,mdn2,E1_0,d1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHn2(i)= rH_n2(et(i),E1_0,T,d1);
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhn2(i)=rHn2(i)/(e*n2(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+Rhn2(i)*((sign2(i))^2)-Rhp(i)*((sigp(i))^2))/((sig(i))^2);
 
 %% Error Calculation
 Er88(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;
 y88=y88+Er88(i);

end

 Error88(r88)=y88/no;
   X88(r88)=mdn1/m;
  r88=r88+1;
figure(cy*1000+8*100)
  hold on
      plot(mdn1/m,y88/no,'o')
      hold off
end
   
  [Min88 i88dx]= min(Error88);
    mdn1_11= X88(i88dx)*m;
     fprintf('value of mdn1_11: %d\n', mdn1_11);
    fprintf('value of mdn1e: %d\n', mdn1e);
    fprintf('value of mdn1s: %d\n', mdn1s);
    
          if (round(mdn1_11/m,5) > round(mdn1s/m,5) && round(mdn1_11/m,5) < round(mdn1e/m,5))== true;

            break;
        else
            mdn1e=mdn1_11+4*Xm1;
            mdn1s=mdn1_11-4*Xm1;    
         end
end   

%% -----------------------------*()----------------------------------*()----------------------------    
 
for mdn1=mdn1_11-Xm1:Xm1/20:mdn1_11+Xm1;    %% { Loop2 Fine Grid }
Nd=Nd1;
E1_0=E1_01;
d1=d1_1; 
mdn2= mdn2_1*m;
Edefn2=Edefn2_1*e;
Eg0=Eg0_1;
a=a_1;
y8=0;

for i=1:37
T=data(i,1);    
%% Charge Balance Equation (Nd=n1+n2-p)
ND=@(eta)n_1(eta,T,mdn1)+n_2(eta,T,mdn2,E1_0,d1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Three Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sign2(i)=sig_n2(et(i),T,Edefn2,mdn2,E1_0,d1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sign2(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Three Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkn2(i)= Sbk_n2(et(i),E1_0,T,d1);
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)+Sbkn2(i)*sign2(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Three Band System
n1(i)=n_1(et(i),T,mdn1);
n2(i)=n_2(et(i),T,mdn2,E1_0,d1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHn2(i)= rH_n2(et(i),E1_0,T,d1);
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhn2(i)=rHn2(i)/(e*n2(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+Rhn2(i)*((sign2(i))^2)-Rhp(i)*((sigp(i))^2))/((sig(i))^2);

 
%% Error Calculation
 Er8(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;
 y8=y8+Er8(i);

end

 Error8(r8)=y8/no;
 X8(r8)=mdn1/m;
 r8=r8+1;
figure(cy*100+8)
  hold on
  plot(mdn1/m,y8/no,'o')
  hold off
end
[Min8 i8dx]= min(Error8);
    mdn1_1= X8(i8dx);
    
%% *************0**************0*************0************0************0*****************0************  
%% 7.Deformation Potential Conduction Band 1_Edefn1_optimization 
%% *************0**************0*************0************0************0*****************0************    
Xe1=(Edefn1/110)/2;
Edefn1s=(Edefn1-5*Xe1);
Edefn1e=(Edefn1+5*Xe1);
for fa9=1:1:100000
 for Edefn1 =  Edefn1s : Xe1 : Edefn1e;       %% { Loop1 Coarse Grid }   
Nd=Nd1;
E1_0=E1_01;
d1=d1_1; 
mdn2= mdn2_1*m;  
Edefn2=Edefn2_1*e;
Eg0=Eg0_1;
a=a_1;
mdn1=mdn1_1*m; 

y99=0;

for i=1:37
 T=data(i,1);  
%% Charge Balance Equation (Nd=n1+n2-p)
ND=@(eta)n_1(eta,T,mdn1)+n_2(eta,T,mdn2,E1_0,d1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Three Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sign2(i)=sig_n2(et(i),T,Edefn2,mdn2,E1_0,d1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sign2(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Three Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkn2(i)= Sbk_n2(et(i),E1_0,T,d1);
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)+Sbkn2(i)*sign2(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Three Band System
n1(i)=n_1(et(i),T,mdn1);
n2(i)=n_2(et(i),T,mdn2,E1_0,d1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHn2(i)= rH_n2(et(i),E1_0,T,d1);
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhn2(i)=rHn2(i)/(e*n2(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+Rhn2(i)*((sign2(i))^2)-Rhp(i)*((sigp(i))^2))/((sig(i))^2);


 %% Error Calculation
 Er99(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;                            
 y99=y99+Er99(i);

end
 Error99(r99)=y99/no;
   X99(r99)=Edefn1/e;
  r99=r99+1;
figure(cy*1000+9*100)
  hold on
      plot(Edefn1/e,y99/no,'o')
      hold off
end
    [Min99 i99dx]= min(Error99);
    Edefn1_11= X99(i99dx)*e;

    fprintf('value of Edefn1_11: %d\n', Edefn1_11);
    fprintf('value of Edefn1e: %d\n', Edefn1e);
    fprintf('value of Edefn1s: %d\n', Edefn1s);
    
            if (round(Edefn1_11/e,5) > round(Edefn1s/e,5) && round(Edefn1_11/e,5) < round(Edefn1e/e,5))== true
                break;
            else
                Edefn1e=Edefn1_11+4*Xe1;
                Edefn1s=Edefn1_11-4*Xe1;
            
            end

end     
 
%% ----------------------------*()---------------------------------*()------------------------------------------

for Edefn1=(Edefn1_11-Xe1): Xe1/20 : (Edefn1_11+Xe1);  %% { Loo2 Fine Grid }
Nd=Nd1;
E1_0=E1_01;
d1=d1_1; 
mdn2= mdn2_1*m;  
Edefn2=Edefn2_1*e;
Eg0=Eg0_1;
a=a_1;
mdn1=mdn1_1*m; 
y9=0;

for i=1:37
T=data(i,1);    

%% Charge Balance Equation (Nd=n1+n2-p)
ND=@(eta)n_1(eta,T,mdn1)+n_2(eta,T,mdn2,E1_0,d1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Three Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sign2(i)=sig_n2(et(i),T,Edefn2,mdn2,E1_0,d1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sign2(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Three Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkn2(i)= Sbk_n2(et(i),E1_0,T,d1);
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)+Sbkn2(i)*sign2(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Three Band System
n1(i)=n_1(et(i),T,mdn1);
n2(i)=n_2(et(i),T,mdn2,E1_0,d1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHn2(i)= rH_n2(et(i),E1_0,T,d1);
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhn2(i)=rHn2(i)/(e*n2(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+Rhn2(i)*((sign2(i))^2)-Rhp(i)*((sigp(i))^2))/((sig(i))^2);


%% Error Calculation
Er9(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;                            
y9=y9+Er9(i);

end
 Error9(r9)=y9/no;
 X9(r9)=Edefn1/e;
 r9=r9+1;
figure(cy*100+9)
  hold on
  plot(Edefn1/e,y9/no,'o')
  hold off
end
 [Min9 i9dx]= min(Error9);
 Edefn1_1= X9(i9dx);   
  
%% *************0**************0*************0************0************0*****************0************  
%% 8.Grain size_L_ optimization 
%% *************0**************0*************0************0************0*****************0************      
XL=(L/10)/2;
Ls=(L-5*XL);
Le=(L+5*XL);
for fa11=1:1:100000                
 for L =  Ls : XL : Le;       %% { Loop1 Coarse Grid }
Nd=Nd1;
E1_0=E1_01;
d1=d1_1; 
mdn2= mdn2_1*m;  
Edefn2=Edefn2_1*e;
Eg0=Eg0_1;
a=a_1;
mdn1=mdn1_1*m; 
Edefn1=Edefn1_1*e;
y1111=0;

for i=1:37
 T=data(i,1);  
%% Charge Balance Equation (Nd=n1+n2-p)
ND=@(eta)n_1(eta,T,mdn1)+n_2(eta,T,mdn2,E1_0,d1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Three Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sign2(i)=sig_n2(et(i),T,Edefn2,mdn2,E1_0,d1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sign2(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Three Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkn2(i)= Sbk_n2(et(i),E1_0,T,d1);
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)+Sbkn2(i)*sign2(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Three Band System
n1(i)=n_1(et(i),T,mdn1);
n2(i)=n_2(et(i),T,mdn2,E1_0,d1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHn2(i)= rH_n2(et(i),E1_0,T,d1);
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhn2(i)=rHn2(i)/(e*n2(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+Rhn2(i)*((sign2(i))^2)-Rhp(i)*((sigp(i))^2))/((sig(i))^2);


 %% Error Calculation
 Er1111(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;                            
 y1111=y1111+Er1111(i);

end
 Error1111(r1111)=y1111/no;
   X1111(r1111)=L;
  r1111=r1111+1;
figure(cy*100000+11*100)
  hold on
      plot(L,y1111/no,'o')
      hold off
end
    [Min1111 i1111dx]= min(Error1111);
    L_11= X1111(i1111dx);

    fprintf('value of L_11: %d\n', L_11);
    fprintf('value of Le: %d\n', Le);
    fprintf('value of Ls: %d\n', Ls);
    
            if (round(L_11,9) > round(Ls,9) && round(L_11,9) < round(Le,9))== true
                break;
            else
                Le=L_11+4*XL;
                Ls=L_11-4*XL;
            
            end

end     
 
%%----------------------------*()---------------------------------*()------------------------------------------

for L=(L_11-XL): XL/20 : (L_11+XL);   %%  %% { Loop2 Fine Grid }
Nd=Nd1;
E1_0=E1_01;
d1=d1_1; 
mdn2= mdn2_1*m;  
Edefn2=Edefn2_1*e;
Eg0=Eg0_1;
a=a_1;
mdn1=mdn1_1*m; 
Edefn1=Edefn1_1*e;
y11=0;

for i=1:37
T=data(i,1);    

%% Charge Balance Equation (Nd=n1+n2-p)
ND=@(eta)n_1(eta,T,mdn1)+n_2(eta,T,mdn2,E1_0,d1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Three Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sign2(i)=sig_n2(et(i),T,Edefn2,mdn2,E1_0,d1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sign2(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Three Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkn2(i)= Sbk_n2(et(i),E1_0,T,d1);
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)+Sbkn2(i)*sign2(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Three Band System
n1(i)=n_1(et(i),T,mdn1);
n2(i)=n_2(et(i),T,mdn2,E1_0,d1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHn2(i)= rH_n2(et(i),E1_0,T,d1);
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhn2(i)=rHn2(i)/(e*n2(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+Rhn2(i)*((sign2(i))^2)-Rhp(i)*((sigp(i))^2))/((sig(i))^2);


%% Error Calculation
Er11(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;                            
y11=y11+Er11(i);

end
 Error11(r11)=y11/no;
 X11(r11)=L;
 r11=r11+1;
figure(cy*100+11)
  hold on
  plot(L,y11/no,'o')
  hold off
end
 [Min11 i11dx]= min(Error11);
 L_1= X11(i11dx);   
 
%% *************0**************0*************0************0************0*****************0************  
%% 11.Grain Boundary Potential Barrier optimization 
%% *************0**************0*************0************0************0*****************0************    
Xeb=(Eb/10)/2;
Ebs=(Eb-5*Xeb);
Ebe=(Eb+5*Xeb);
for fa10=1:1:100000
 for Eb =  Ebs : Xeb : Ebe;        %% { Loop1 Coarse Grid }
Nd=Nd1;
E1_0=E1_01;
d1=d1_1; 
mdn2= mdn2_1*m;  
Edefn2=Edefn2_1*e;
Eg0=Eg0_1;
a=a_1;
mdn1=mdn1_1*m; 
Edefn1=Edefn1_1*e;
L=L_1;
y1010=0;

for i=1:37
 T=data(i,1);  
%% Charge Balance Equation (Nd=n1+n2-p)
ND=@(eta)n_1(eta,T,mdn1)+n_2(eta,T,mdn2,E1_0,d1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Sigma for three band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sign2(i)=sig_n2(et(i),T,Edefn2,mdn2,E1_0,d1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sign2(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Three Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkn2(i)= Sbk_n2(et(i),E1_0,T,d1);
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)+Sbkn2(i)*sign2(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Three Band System
n1(i)=n_1(et(i),T,mdn1);
n2(i)=n_2(et(i),T,mdn2,E1_0,d1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHn2(i)= rH_n2(et(i),E1_0,T,d1);
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhn2(i)=rHn2(i)/(e*n2(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+Rhn2(i)*((sign2(i))^2)-Rhp(i)*((sigp(i))^2))/((sig(i))^2);


 %% Error Calculation
 Er1010(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;                            
 y1010=y1010+Er1010(i);

end
 Error1010(r1010)=y1010/no;
   X1010(r1010)=Eb;
  r1010=r1010+1;
figure(cy*1000+10*100)
  hold on
      plot(Eb,y1010/no,'o')
      hold off
end
    [Min1010 i1010dx]= min(Error1010);
    Eb_11= X1010(i1010dx);

    fprintf('value of Eb_11: %d\n', Eb_11);
    fprintf('value of Ebe: %d\n', Ebe);
    fprintf('value of Ebs: %d\n', Ebs);
            if (round(Eb_11,5) > round(Ebs,5) && round(Eb_11,5) < round(Ebe,5))== true
                break;
            else
                Ebe=Eb_11+4*Xeb;
                Ebs=Eb_11-4*Xeb;
            
            end

end     
 
%% ----------------------------*()---------------------------------*()------------------------------------------

for Eb=(Eb_11-Xeb): Xeb/20 : (Eb_11+Xeb);   %%  %% { Loop2 Fine Grid }
Nd=Nd1;
E1_0=E1_01;
d1=d1_1; 
mdn2= mdn2_1*m;  
Edefn2=Edefn2_1*e;
Eg0=Eg0_1;
a=a_1;
mdn1=mdn1_1*m; 
Edefn1=Edefn1_1*e;
L=L_1;
y10=0;

for i=1:37
T=data(i,1);    

%% Charge Balance Equation (Nd=n1+n2-p)
ND=@(eta)n_1(eta,T,mdn1)+n_2(eta,T,mdn2,E1_0,d1)-n_p(eta,T,a,mdp,Eg0);
et(i)=fzero(@(eta)ND(eta)-Nd,4);

%% Calculate Electrical Conductivity for Three Band system
sign1(i)=sig_n1(et(i),T,Edefn1,mdn1,Eb,L);
sign2(i)=sig_n2(et(i),T,Edefn2,mdn2,E1_0,d1,Eb,L);
sigp(i)=sig_p(et(i),T,Edefp,mdp,a,Eg0,Eb,L);
sig(i)=sign1(i)+sign2(i)+sigp(i);
 
%% Calculate Seebeck Coefficient  for Three Band System
Sbkn1(i)=Sbk_n1(et(i));               
Sbkn2(i)= Sbk_n2(et(i),E1_0,T,d1);
Sbkp(i)=Sbk_p(et(i),T,a,Eg0);
Sbk(i)=(Sbkn1(i)*sign1(i)+Sbkn2(i)*sign2(i)-Sbkp(i)*sigp(i))/sig(i);

%% Read Experimental Values
sig_exp(i)=data(i,3)*100;
RH_exp(i)= data(i,4);
Sbk_exp(i)=data(i,2)*1e-6;

%% Calculate RH for Three Band System
n1(i)=n_1(et(i),T,mdn1);
n2(i)=n_2(et(i),T,mdn2,E1_0,d1);
p(i)=n_p(et(i),T,a,mdp,Eg0);
rHn1(i)= rH_n1(et(i));
rHn2(i)= rH_n2(et(i),E1_0,T,d1);
rHp(i)=rH_p(et(i),T,a,Eg0);
Rhn1(i)=rHn1(i)/(e*n1(i));
Rhn2(i)=rHn2(i)/(e*n2(i));
Rhp(i)=rHp(i)/(e*p(i));
RH(i)=(Rhn1(i)*((sign1(i))^2)+Rhn2(i)*((sign2(i))^2)-Rhp(i)*((sigp(i))^2))/((sig(i))^2);


%% Error Calculation
Er10(i)=(1-(sig_exp(i)/sig(i)))^2+(1-(Sbk_exp(i)/Sbk(i)))^2+(1-(RH_exp(i)/RH(i)))^2;                            
y10=y10+Er10(i);

end
 Error10(r10)=y10/no;
 X10(r10)=Eb;
 r10=r10+1;
figure(cy*100+10)
  hold on
  plot(Eb,y10/no,'o')
  hold off
end
 [Min10 i10dx]= min(Error10);
 Eb_1= X10(i10dx);   
  
 
%% =====================================================  
 %% Output excel file generation for optimized parameters  
 %% =====================================================
 store(1,cy)=Nd1;
 store(2,cy)=E1_01;
 store(3,cy)=d1_1;
 store(4,cy)=mdn2_1;
 store(5,cy)=Edefn2_1;
 store(6,cy)=Eg0_1;
 store(7,cy)=a_1;
 store(8,cy)=mdn1_1;
 store(9,cy)=Edefn1_1;
 store(10,cy)=Eb_1;
 store(11,cy)=L_1;
 store(12,cy)=Min11;

xlswrite('Parameter_File.xlsx',store)

end